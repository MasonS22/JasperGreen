﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace JasperGreen.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    CustomerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerFirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CustomerLastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CustomerEmail = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CustomerPhone = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    BillingAddress = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    BillingCity = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    BillingState = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BillingZIP = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.CustomerID);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    EmployeeID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeFirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    EmployeeLastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    SSN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    JobTitle = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    HourlyRate = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.EmployeeID);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    PaymentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerID = table.Column<int>(type: "int", nullable: false),
                    PaymentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaymentAmount = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.PaymentID);
                    table.ForeignKey(
                        name: "FK_Payments_Customers_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Properties",
                columns: table => new
                {
                    PropertyID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PropertyAddress = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PropertyCity = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PropertyState = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PropertyZIP = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    ServiceFee = table.Column<double>(type: "float", nullable: false),
                    CustomerID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Properties", x => x.PropertyID);
                    table.ForeignKey(
                        name: "FK_Properties_Customers_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Crews",
                columns: table => new
                {
                    CrewID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrewName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CrewForemanID = table.Column<int>(type: "int", nullable: false),
                    CrewMember1ID = table.Column<int>(type: "int", nullable: false),
                    CrewMember2ID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Crews", x => x.CrewID);
                    table.ForeignKey(
                        name: "FK_Crews_Employees_CrewForemanID",
                        column: x => x.CrewForemanID,
                        principalTable: "Employees",
                        principalColumn: "EmployeeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Crews_Employees_CrewMember1ID",
                        column: x => x.CrewMember1ID,
                        principalTable: "Employees",
                        principalColumn: "EmployeeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Crews_Employees_CrewMember2ID",
                        column: x => x.CrewMember2ID,
                        principalTable: "Employees",
                        principalColumn: "EmployeeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProvideServices",
                columns: table => new
                {
                    ProvideServiceID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrewID = table.Column<int>(type: "int", nullable: false),
                    CustomerID = table.Column<int>(type: "int", nullable: false),
                    PropertyID = table.Column<int>(type: "int", nullable: false),
                    ProvideServiceDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ProvideServiceFee = table.Column<double>(type: "float", nullable: false),
                    PaymentID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProvideServices", x => x.ProvideServiceID);
                    table.ForeignKey(
                        name: "FK_ProvideServices_Crews_CrewID",
                        column: x => x.CrewID,
                        principalTable: "Crews",
                        principalColumn: "CrewID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProvideServices_Customers_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProvideServices_Payments_PaymentID",
                        column: x => x.PaymentID,
                        principalTable: "Payments",
                        principalColumn: "PaymentID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProvideServices_Properties_PropertyID",
                        column: x => x.PropertyID,
                        principalTable: "Properties",
                        principalColumn: "PropertyID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "CustomerID", "BillingAddress", "BillingCity", "BillingState", "BillingZIP", "CustomerEmail", "CustomerFirstName", "CustomerLastName", "CustomerPhone" },
                values: new object[,]
                {
                    { 1, "7064 East Pawnee Drive", "Sacramento", "California", "48756", "SCharlie@gmail.com", "Sammy", "Charlie", "321-453-6164" },
                    { 2, "8313 Canal Avenue", "Niceville", "Florida", "12931", "RylieL@yahoo.com", "Rylie", "Lizzie", "828-389-3013" },
                    { 3, "48 West Marshall Street", "Los Angeles", "California", "53234", "AnayaKarissa74@outlook.com", "Anaya", "Karissa", "713-234-4558" },
                    { 4, "897 Schoolhouse St.", "Goose Creek", "South Carolina", "79764", "EmilyTaylor@gmail.com", "Emily", "Taylor", "916-555-1212" },
                    { 5, "952 Mayfair Street", "Danvers", "Massachusetts", "26301", "JessHarrison@hotmail.com", "Jessica", "Harrison", "415-777-9001" }
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "EmployeeID", "EmployeeFirstName", "EmployeeLastName", "HireDate", "HourlyRate", "JobTitle", "SSN" },
                values: new object[,]
                {
                    { 1, "Dash", "Cullen", new DateTime(2022, 2, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 25.5, "Lawn Mower Operator", "588-25-3170" },
                    { 2, "Sophia", "Greene", new DateTime(2021, 6, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 30.0, "Lawn Care Specialist", "231-47-8901" },
                    { 3, "James", "Hart", new DateTime(2020, 11, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), 18.75, "Groundskeeper", "392-80-1246" },
                    { 4, "Mia", "Clark", new DateTime(2022, 8, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), 22.0, "Landscape Maintenance Worker", "523-94-6758" },
                    { 5, "Liam", "Foster", new DateTime(2021, 3, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), 28.5, "Lawn Care Technician", "774-36-4532" },
                    { 6, "Emily", "Parker", new DateTime(2019, 1, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), 23.5, "Landscape Technician", "409-72-2235" },
                    { 7, "Ethan", "Davis", new DateTime(2020, 7, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), 27.0, "Garden Care Specialist", "614-84-8922" },
                    { 8, "Ava", "Lee", new DateTime(2022, 4, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), 32.0, "Turf Management Specialist", "548-95-1937" },
                    { 9, "Oliver", "Thompson", new DateTime(2021, 9, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 19.25, "Landscape Crew Member", "290-12-5491" },
                    { 10, "Isabella", "Martinez", new DateTime(2021, 4, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), 20.0, "Lawn Service Worker", "379-52-3982" },
                    { 11, "Lucas", "Rodriguez", new DateTime(2020, 10, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), 35.0, "Mowing Crew Leader", "522-65-7383" },
                    { 12, "Charlotte", "Young", new DateTime(2022, 1, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), 31.0, "Turf Care Professional", "874-15-2836" },
                    { 13, "Benjamin", "Scott", new DateTime(2021, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 26.0, "Residential Lawn Mowing Technician", "466-29-1224" },
                    { 14, "Amelia", "Harris", new DateTime(2022, 9, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), 24.0, "Commercial Grounds Maintenance Worker", "378-85-6410" },
                    { 15, "Henry", "Evans", new DateTime(2019, 5, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), 22.75, "Lawn Equipment Operator", "324-55-3948" }
                });

            migrationBuilder.InsertData(
                table: "Crews",
                columns: new[] { "CrewID", "CrewForemanID", "CrewMember1ID", "CrewMember2ID", "CrewName" },
                values: new object[,]
                {
                    { 1, 2, 5, 14, "Fixers" },
                    { 2, 6, 10, 15, "Mowers" },
                    { 3, 4, 7, 12, "Growers" },
                    { 4, 10, 11, 13, "Cleaners" },
                    { 5, 8, 9, 3, "Whackers" }
                });

            migrationBuilder.InsertData(
                table: "Payments",
                columns: new[] { "PaymentID", "CustomerID", "PaymentAmount", "PaymentDate" },
                values: new object[,]
                {
                    { 1, 3, 220.99000000000001, new DateTime(2023, 5, 25, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, 2, 310.56999999999999, new DateTime(2023, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, 5, 234.99000000000001, new DateTime(2023, 6, 19, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, 1, 235.40000000000001, new DateTime(2023, 7, 9, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, 4, 305.0, new DateTime(2023, 7, 29, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "Properties",
                columns: new[] { "PropertyID", "CustomerID", "PropertyAddress", "PropertyCity", "PropertyState", "PropertyZIP", "ServiceFee" },
                values: new object[,]
                {
                    { 1, 2, "8313 Canal Avenue", "Niceville", "Florida", "12931", 120.0 },
                    { 2, 1, "7064 East Pawnee Drive", "Sacramento", "California", "48756", 100.0 },
                    { 3, 4, "897 Schoolhouse St.", "Goose Creek", "South Carolina", "79764", 135.0 },
                    { 4, 5, "952 Mayfair Street", "Danvers", "Massachusetts", "26301", 85.0 },
                    { 5, 3, "48 West Marshall Street", "Los Angeles", "California", "53234", 90.0 },
                    { 6, 2, "1250 Brookside Drive", "Orlando", "Florida", "32145", 200.0 },
                    { 7, 4, "3087 Rosewood Lane", "Denver", "Colorado", "80123", 170.0 },
                    { 8, 1, "1789 Fairview Parkway", "Dallas", "Texas", "75201", 140.0 },
                    { 9, 5, "4920 Maple Ridge Road", "Miami", "Florida", "33101", 150.0 },
                    { 10, 3, "6801 Horizon Street", "Phoenix", "Arizona", "85001", 145.0 }
                });

            migrationBuilder.InsertData(
                table: "ProvideServices",
                columns: new[] { "ProvideServiceID", "CrewID", "CustomerID", "PaymentID", "PropertyID", "ProvideServiceDate", "ProvideServiceFee" },
                values: new object[,]
                {
                    { 1, 3, 3, 1, 10, new DateTime(2023, 5, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), 130.99000000000001 },
                    { 2, 2, 3, 1, 5, new DateTime(2023, 5, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), 90.0 },
                    { 3, 2, 2, 2, 1, new DateTime(2023, 6, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), 110.56999999999999 },
                    { 4, 4, 5, 3, 4, new DateTime(2023, 6, 9, 0, 0, 0, 0, DateTimeKind.Unspecified), 84.989999999999995 },
                    { 5, 4, 2, 2, 6, new DateTime(2023, 6, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 200.0 },
                    { 6, 1, 5, 3, 9, new DateTime(2023, 6, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), 150.0 },
                    { 7, 1, 1, 4, 8, new DateTime(2023, 7, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 135.40000000000001 },
                    { 8, 5, 1, 4, 2, new DateTime(2023, 7, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), 100.0 },
                    { 9, 3, 4, 5, 3, new DateTime(2023, 7, 21, 0, 0, 0, 0, DateTimeKind.Unspecified), 135.0 },
                    { 10, 5, 4, 5, 7, new DateTime(2023, 7, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), 170.0 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewForemanID",
                table: "Crews",
                column: "CrewForemanID");

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewMember1ID",
                table: "Crews",
                column: "CrewMember1ID");

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewMember2ID",
                table: "Crews",
                column: "CrewMember2ID");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_CustomerID",
                table: "Payments",
                column: "CustomerID");

            migrationBuilder.CreateIndex(
                name: "IX_Properties_CustomerID",
                table: "Properties",
                column: "CustomerID");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideServices_CrewID",
                table: "ProvideServices",
                column: "CrewID");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideServices_CustomerID",
                table: "ProvideServices",
                column: "CustomerID");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideServices_PaymentID",
                table: "ProvideServices",
                column: "PaymentID");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideServices_PropertyID",
                table: "ProvideServices",
                column: "PropertyID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProvideServices");

            migrationBuilder.DropTable(
                name: "Crews");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "Properties");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
