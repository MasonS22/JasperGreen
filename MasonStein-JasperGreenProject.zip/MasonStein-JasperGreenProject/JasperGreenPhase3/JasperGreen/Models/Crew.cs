﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - Crew Class
//PURPOSE:    The Crew class represents all information and context needed for Jasper Green
//            to create and manage crews.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JasperGreen.Models
{
    public class Crew
    {
        public int CrewID { get; set; } // primary key property

		[Required(ErrorMessage = "Enter a crew name.")]
		public string CrewName { get; set; } = string.Empty;

        public int CrewForemanID { get; set; }

        [ValidateNever]
        [ForeignKey(nameof(CrewForemanID))]
        public Employee CrewForeman { get; set; } = null!;  // foreign key property

        public int CrewMember1ID { get; set; }

        [ValidateNever]
        [ForeignKey(nameof(CrewMember1ID))]
        public Employee CrewMember1 { get; set; } = null!;  // foreign key property

        public int CrewMember2ID { get; set; }

        [ValidateNever]
        [ForeignKey(nameof(CrewMember2ID))]
        public Employee CrewMember2 { get; set; } = null!;  // foreign key property

		[ValidateNever]
		public ICollection<ProvideService> ProvideServices { get; set; } = null!;   // navigation property
    }
}
