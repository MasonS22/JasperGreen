﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - JasperGreenContext
//PURPOSE:    The JasperGreenContext model represents all JasperGreenContext categories, and seeds them with
//            data. Not only that, it also helps with building certain relationships between classes.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using Microsoft.EntityFrameworkCore;
using JasperGreen.Models;
using Microsoft.EntityFrameworkCore.Internal;

namespace JasperGreen.Models
{
    public class JasperGreenContext : DbContext
    {
        public JasperGreenContext(DbContextOptions<JasperGreenContext> options) : base(options) { }

        // add DbSet for all domain models
        public DbSet<Customer> Customers { get; set; } = null!;

        public DbSet<Employee> Employees { get; set; } = null!;

        public DbSet<Property> Properties { get; set; } = null!;

        public DbSet<Payment> Payments { get; set; } = null!;

        public DbSet<Crew> Crews { get; set; } = null!;

        public DbSet<ProvideService> ProvideServices { get; set; } = null!;


        // add Fluent API code to represent relationships and insert seed data
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Customer Seed Data
            modelBuilder.Entity<Customer>().HasData(
                new Customer { CustomerID = 1, CustomerFirstName = "Sammy", CustomerLastName = "Charlie", CustomerEmail = "SCharlie@gmail.com", CustomerPhone = "321-453-6164", BillingAddress = "7064 East Pawnee Drive", BillingCity = "Sacramento", BillingState = "California", BillingZIP = "48756" },
                new Customer { CustomerID = 2, CustomerFirstName = "Rylie", CustomerLastName = "Lizzie", CustomerEmail = "RylieL@yahoo.com", CustomerPhone = "828-389-3013", BillingAddress = "8313 Canal Avenue", BillingCity = "Niceville", BillingState = "Florida", BillingZIP = "12931" },
                new Customer { CustomerID = 3, CustomerFirstName = "Anaya", CustomerLastName = "Karissa", CustomerEmail = "AnayaKarissa74@outlook.com", CustomerPhone = "713-234-4558", BillingAddress = "48 West Marshall Street", BillingCity = "Los Angeles", BillingState = "California", BillingZIP = "53234" },
                new Customer { CustomerID = 4, CustomerFirstName = "Emily", CustomerLastName = "Taylor", CustomerEmail = "EmilyTaylor@gmail.com", CustomerPhone = "916-555-1212", BillingAddress = "897 Schoolhouse St.", BillingCity = "Goose Creek", BillingState = "South Carolina", BillingZIP = "79764" },
                new Customer { CustomerID = 5, CustomerFirstName = "Jessica", CustomerLastName = "Harrison", CustomerEmail = "JessHarrison@hotmail.com", CustomerPhone = "415-777-9001", BillingAddress = "952 Mayfair Street", BillingCity = "Danvers", BillingState = "Massachusetts", BillingZIP = "26301" }
                );

            // Employee Seed Data
            modelBuilder.Entity<Employee>().HasData(
                new Employee { EmployeeID = 1, EmployeeFirstName = "Dash", EmployeeLastName = "Cullen", SSN = "588-25-3170", JobTitle = "Lawn Mower Operator", HireDate = DateTime.Parse("2022-02-10"), HourlyRate = 25.50 },
                new Employee { EmployeeID = 2, EmployeeFirstName = "Sophia", EmployeeLastName = "Greene", SSN = "231-47-8901", JobTitle = "Lawn Care Specialist", HireDate = DateTime.Parse("2021-06-15"), HourlyRate = 30.00 },
                new Employee { EmployeeID = 3, EmployeeFirstName = "James", EmployeeLastName = "Hart", SSN = "392-80-1246", JobTitle = "Groundskeeper", HireDate = DateTime.Parse("2020-11-05"), HourlyRate = 18.75 },
                new Employee { EmployeeID = 4, EmployeeFirstName = "Mia", EmployeeLastName = "Clark", SSN = "523-94-6758", JobTitle = "Landscape Maintenance Worker", HireDate = DateTime.Parse("2022-08-20"), HourlyRate = 22.00 },
                new Employee { EmployeeID = 5, EmployeeFirstName = "Liam", EmployeeLastName = "Foster", SSN = "774-36-4532", JobTitle = "Lawn Care Technician", HireDate = DateTime.Parse("2021-03-12"), HourlyRate = 28.50 },
                new Employee { EmployeeID = 6, EmployeeFirstName = "Emily", EmployeeLastName = "Parker", SSN = "409-72-2235", JobTitle = "Landscape Technician", HireDate = DateTime.Parse("2019-01-08"), HourlyRate = 23.50 },
                new Employee { EmployeeID = 7, EmployeeFirstName = "Ethan", EmployeeLastName = "Davis", SSN = "614-84-8922", JobTitle = "Garden Care Specialist", HireDate = DateTime.Parse("2020-07-17"), HourlyRate = 27.00 },
                new Employee { EmployeeID = 8, EmployeeFirstName = "Ava", EmployeeLastName = "Lee", SSN = "548-95-1937", JobTitle = "Turf Management Specialist", HireDate = DateTime.Parse("2022-04-25"), HourlyRate = 32.00 },
                new Employee { EmployeeID = 9, EmployeeFirstName = "Oliver", EmployeeLastName = "Thompson", SSN = "290-12-5491", JobTitle = "Landscape Crew Member", HireDate = DateTime.Parse("2021-09-10"), HourlyRate = 19.25 },
                new Employee { EmployeeID = 10, EmployeeFirstName = "Isabella", EmployeeLastName = "Martinez", SSN = "379-52-3982", JobTitle = "Lawn Service Worker", HireDate = DateTime.Parse("2021-04-22"), HourlyRate = 20.00 },
                new Employee { EmployeeID = 11, EmployeeFirstName = "Lucas", EmployeeLastName = "Rodriguez", SSN = "522-65-7383", JobTitle = "Mowing Crew Leader", HireDate = DateTime.Parse("2020-10-30"), HourlyRate = 35.00 },
                new Employee { EmployeeID = 12, EmployeeFirstName = "Charlotte", EmployeeLastName = "Young", SSN = "874-15-2836", JobTitle = "Turf Care Professional", HireDate = DateTime.Parse("2022-01-17"), HourlyRate = 31.00 },
                new Employee { EmployeeID = 13, EmployeeFirstName = "Benjamin", EmployeeLastName = "Scott", SSN = "466-29-1224", JobTitle = "Residential Lawn Mowing Technician", HireDate = DateTime.Parse("2021-11-01"), HourlyRate = 26.00 },
                new Employee { EmployeeID = 14, EmployeeFirstName = "Amelia", EmployeeLastName = "Harris", SSN = "378-85-6410", JobTitle = "Commercial Grounds Maintenance Worker", HireDate = DateTime.Parse("2022-09-12"), HourlyRate = 24.00 },
                new Employee { EmployeeID = 15, EmployeeFirstName = "Henry", EmployeeLastName = "Evans", SSN = "324-55-3948", JobTitle = "Lawn Equipment Operator", HireDate = DateTime.Parse("2019-05-22"), HourlyRate = 22.75 }
                );

            // Property Seed Data
            modelBuilder.Entity<Property>().HasData(
                new Property { PropertyID = 1, CustomerID = 2, PropertyAddress = "8313 Canal Avenue", PropertyCity = "Niceville", PropertyState = "Florida", PropertyZIP = "12931", ServiceFee = 120 },
                new Property { PropertyID = 2, CustomerID = 1, PropertyAddress = "7064 East Pawnee Drive", PropertyCity = "Sacramento", PropertyState = "California", PropertyZIP = "48756", ServiceFee = 100 },
                new Property { PropertyID = 3, CustomerID = 4, PropertyAddress = "897 Schoolhouse St.", PropertyCity = "Goose Creek", PropertyState = "South Carolina", PropertyZIP = "79764", ServiceFee = 135 },
                new Property { PropertyID = 4, CustomerID = 5, PropertyAddress = "952 Mayfair Street", PropertyCity = "Danvers", PropertyState = "Massachusetts", PropertyZIP = "26301", ServiceFee = 85 },
                new Property { PropertyID = 5, CustomerID = 3, PropertyAddress = "48 West Marshall Street", PropertyCity = "Los Angeles", PropertyState = "California", PropertyZIP = "53234", ServiceFee = 90 },
                new Property { PropertyID = 6, CustomerID = 2, PropertyAddress = "1250 Brookside Drive", PropertyCity = "Orlando", PropertyState = "Florida", PropertyZIP = "32145", ServiceFee = 200 },
                new Property { PropertyID = 7, CustomerID = 4, PropertyAddress = "3087 Rosewood Lane", PropertyCity = "Denver", PropertyState = "Colorado", PropertyZIP = "80123", ServiceFee = 170 },
                new Property { PropertyID = 8, CustomerID = 1, PropertyAddress = "1789 Fairview Parkway", PropertyCity = "Dallas", PropertyState = "Texas", PropertyZIP = "75201", ServiceFee = 140 },
                new Property { PropertyID = 9, CustomerID = 5, PropertyAddress = "4920 Maple Ridge Road", PropertyCity = "Miami", PropertyState = "Florida", PropertyZIP = "33101", ServiceFee = 150 },
                new Property { PropertyID = 10, CustomerID = 3, PropertyAddress = "6801 Horizon Street", PropertyCity = "Phoenix", PropertyState = "Arizona", PropertyZIP = "85001", ServiceFee = 145 }
                );

            //Payment Seed Data
            modelBuilder.Entity<Payment>().HasData(
                new Payment { PaymentID = 1, CustomerID = 3, PaymentDate = DateTime.Parse("2023-05-25"), PaymentAmount = 220.99 },
                new Payment { PaymentID = 2, CustomerID = 2, PaymentDate = DateTime.Parse("2023-06-10"), PaymentAmount = 310.57 },
                new Payment { PaymentID = 3, CustomerID = 5, PaymentDate = DateTime.Parse("2023-06-19"), PaymentAmount = 234.99 },
                new Payment { PaymentID = 4, CustomerID = 1, PaymentDate = DateTime.Parse("2023-07-09"), PaymentAmount = 235.40 },
                new Payment { PaymentID = 5, CustomerID = 4, PaymentDate = DateTime.Parse("2023-07-29"), PaymentAmount = 305 }
                );

            //Crew Relationship Builders and Seed Data
            modelBuilder.Entity<Crew>()
                .HasOne(c => c.CrewForeman)
                .WithMany(e => e.Crews)
                .HasForeignKey(cf => cf.CrewForemanID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Crew>()
                .HasOne(c => c.CrewMember1)
                .WithMany(e => e.Member1)
                .HasForeignKey(cf => cf.CrewMember1ID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Crew>()
                .HasOne(c => c.CrewMember2)
                .WithMany(e => e.Member2)
                .HasForeignKey(cf => cf.CrewMember2ID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Crew>().HasData(
                new Crew { CrewID = 1, CrewName = "Fixers", CrewForemanID = 2, CrewMember1ID = 5, CrewMember2ID = 14},
                new Crew { CrewID = 2, CrewName = "Mowers", CrewForemanID = 6, CrewMember1ID = 10, CrewMember2ID = 15 },
                new Crew { CrewID = 3, CrewName = "Growers", CrewForemanID = 4, CrewMember1ID = 7, CrewMember2ID = 12 },
                new Crew { CrewID = 4, CrewName = "Cleaners", CrewForemanID = 10, CrewMember1ID = 11, CrewMember2ID = 13 },
                new Crew { CrewID = 5, CrewName = "Whackers", CrewForemanID = 8, CrewMember1ID = 9, CrewMember2ID = 3 }
                );

            //ProvideService Relationship Builders and Seed Data
            modelBuilder.Entity<ProvideService>()
                .HasOne(ps => ps.Payment)
                .WithMany(p => p.ProvideServices)
                .HasForeignKey(ps => ps.PaymentID)
                .OnDelete(DeleteBehavior.Restrict);
            
            modelBuilder.Entity<ProvideService>()
                .HasOne(ps => ps.Customer)
                .WithMany(c => c.ProvideServices)
                .HasForeignKey(ps => ps.CustomerID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ProvideService>()
                .HasOne(ps => ps.Property)
                .WithMany(p => p.ProvideServices)
                .HasForeignKey(ps => ps.PropertyID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ProvideService>()
                .HasOne(ps => ps.Crew)
                .WithMany(c => c.ProvideServices)
                .HasForeignKey(ps => ps.CrewID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<ProvideService>().HasData(
                new ProvideService { ProvideServiceID = 1, CrewID = 3, CustomerID = 3, PropertyID = 10, ProvideServiceDate = DateTime.Parse("2023-05-16"), ProvideServiceFee = 130.99, PaymentID = 1},
                new ProvideService { ProvideServiceID = 2, CrewID = 2, CustomerID = 3, PropertyID = 5, ProvideServiceDate = DateTime.Parse("2023-05-20"), ProvideServiceFee = 90, PaymentID = 1 },
                new ProvideService { ProvideServiceID = 3, CrewID = 2, CustomerID = 2, PropertyID = 1, ProvideServiceDate = DateTime.Parse("2023-06-02"), ProvideServiceFee = 110.57, PaymentID = 2},
                new ProvideService { ProvideServiceID = 4, CrewID = 4, CustomerID = 5, PropertyID = 4, ProvideServiceDate = DateTime.Parse("2023-06-09"), ProvideServiceFee = 84.99, PaymentID = 3},
                new ProvideService { ProvideServiceID = 5, CrewID = 4, CustomerID = 2, PropertyID = 6, ProvideServiceDate = DateTime.Parse("2023-06-10"), ProvideServiceFee = 200, PaymentID = 2 },
                new ProvideService { ProvideServiceID = 6, CrewID = 1, CustomerID = 5, PropertyID = 9, ProvideServiceDate = DateTime.Parse("2023-06-14"), ProvideServiceFee = 150, PaymentID = 3 },
                new ProvideService { ProvideServiceID = 7, CrewID = 1, CustomerID = 1, PropertyID = 8, ProvideServiceDate = DateTime.Parse("2023-07-01"), ProvideServiceFee = 135.40, PaymentID = 4},
                new ProvideService { ProvideServiceID = 8, CrewID = 5, CustomerID = 1, PropertyID = 2, ProvideServiceDate = DateTime.Parse("2023-07-08"), ProvideServiceFee = 100, PaymentID = 4 },
                new ProvideService { ProvideServiceID = 9, CrewID = 3, CustomerID = 4, PropertyID = 3, ProvideServiceDate = DateTime.Parse("2023-07-21"), ProvideServiceFee = 135, PaymentID = 5},
                new ProvideService { ProvideServiceID = 10, CrewID = 5, CustomerID = 4, PropertyID = 7, ProvideServiceDate = DateTime.Parse("2023-07-26"), ProvideServiceFee = 170, PaymentID = 5}
                );
        }

    }
}
