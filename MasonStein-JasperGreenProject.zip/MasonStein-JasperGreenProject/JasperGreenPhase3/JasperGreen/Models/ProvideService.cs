﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - ProviedService Class
//PURPOSE:    The ProvideService class represents all information and context needed for Jasper Green
//            to create and manage items that keep track of the comapny's services provided and to whom.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace JasperGreen.Models
{
    public class ProvideService
    {
        public int ProvideServiceID { get; set; }   // primary key property

        public int CrewID { get; set; }     // foreign key property

        public int CustomerID { get; set; } // foreign key property

        public int PropertyID { get; set; } // foreign key property

        public DateTime ProvideServiceDate { get; set; }

        public double ProvideServiceFee { get; set; }

        public int PaymentID { get; set; }  // foreign key property


        [ValidateNever]
        public Customer Customer { get; set; } = null!; // navigation property

        [ValidateNever]
        public Property Property { get; set; } = null!; // navigation property

        [ValidateNever]
        public Payment Payment { get; set; } = null!;   // navigation property

        [ValidateNever]
        public Crew Crew { get; set; } = null!;         // navigation property
    }
}
