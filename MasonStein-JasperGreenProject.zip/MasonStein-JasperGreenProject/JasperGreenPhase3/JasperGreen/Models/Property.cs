﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - Property Class
//PURPOSE:    The Property class represents all information and context needed for Jasper Green
//            to create and manage properties.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace JasperGreen.Models
{
    public class Property
    {
        public int PropertyID { get; set; } // primary key property

        [Required(ErrorMessage = "Enter a property address.")]
		[StringLength(50)]
		public string PropertyAddress { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a property city.")]
		[StringLength(50)]
		public string PropertyCity { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a property state.")]
		[StringLength(50)]
		public string PropertyState { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a property ZIP code.")]
		[StringLength(20)]
		public string PropertyZIP {  get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a service fee.")]
		[Range(0, 999999999, ErrorMessage = "Service fee should be greater than 0.")]
		public double ServiceFee { get; set; }

        [Required(ErrorMessage = "Choose a customer.")]
        public int CustomerID { get; set; }     // foreign key property

        [ValidateNever]
        public Customer Customer { get; set; } = null!;  // navigation property

        [ValidateNever]
        public ICollection<ProvideService> ProvideServices { get; set; } = null!;   // navigation property
    }
}
