﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - Customer Class
//PURPOSE:    The Customer class represents all information and context needed for Jasper Green
//            to create and manage customers.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace JasperGreen.Models
{
    public class Customer
    {
        /// <summary>
        /// Another way to create navigation properties.
        /// </summary>
        //public Customer()
        //{
        //    Properties = new HashSet<Property>();

        //    Payments = new HashSet<Payment>();
        //}

        public int CustomerID { get; set; } // primary key property

        [Required(ErrorMessage = "Enter a first name.")]
		[StringLength(50)]
		public string CustomerFirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a last name.")]
		[StringLength(50)]
		public string CustomerLastName { get; set; } = string.Empty;

		[RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$",
			ErrorMessage = "Enter a valid email address.")]
		[StringLength(50)]
		public string CustomerEmail { get; set; } = string.Empty;

		[RegularExpression(@"^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$",
			ErrorMessage = "Phone number must be in (999) 999-9999 format.")]
		[StringLength(20)]
		public string CustomerPhone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a billing address.")]
		[StringLength(50)]
		public string BillingAddress { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a billing city.")]
		[StringLength(50)]
		public string BillingCity { get; set; } = string.Empty;

        [Required(ErrorMessage = "Choose a billing state.")]
		public string BillingState { get; set; } = string.Empty;

        [RegularExpression(@"^\d{5}(-\d{4})?$",
            ErrorMessage = "ZIP Code must be in 99999 format, or 99999-9999 format.")]
		[StringLength(20)]
		public string BillingZIP { get; set; } = string.Empty;

        [ValidateNever]
        public ICollection<Property> Properties { get; set; } = null!;   // navigation property

        [ValidateNever]
        public ICollection<Payment> Payments { get; set; } = null!;      // navigation property

        [ValidateNever]
        public ICollection<ProvideService> ProvideServices { get; set; } = null!;   // navigation property

        [ValidateNever]
        public string CustomerFullName => CustomerFirstName + " " + CustomerLastName;   // read-only property
    }
}
