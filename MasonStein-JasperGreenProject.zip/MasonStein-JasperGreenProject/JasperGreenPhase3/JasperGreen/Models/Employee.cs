﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - Employee Class
//PURPOSE:    The Employee class represents all information and context needed for Jasper Green
//            to create and manage employees.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JasperGreen.Models
{
    public class Employee
    {
        public int EmployeeID { get; set; } // primary key property

        [Required(ErrorMessage = "Enter a first name.")]
		[StringLength(50)]
		public string EmployeeFirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a last name.")]
		[StringLength(50)]
		public string EmployeeLastName { get; set; } = string.Empty;

        [RegularExpression(@"^\d{3}-\d{2}-\d{4}$",
            ErrorMessage = "SSN must be in the format 999-99-9999.")]
        public string SSN { get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a job title.")]
		[StringLength(50)]
		public string JobTitle {  get; set; } = string.Empty;

        [Required(ErrorMessage = "Enter a valid hiring date.")]
        public DateTime HireDate { get; set; }

        [Required(ErrorMessage = "Enter an hourly pay rate.")]
		[Range(0, 999999999, ErrorMessage = "Hourly pay rate should be greater than 0.")]
		public double HourlyRate { get; set; }

        [ValidateNever]
        public ICollection<Crew> Crews { get; set; } = null!;   // navigation property

        [ValidateNever]
        public ICollection<Crew> Member1 { get; set; } = null!; // navigation property

        [ValidateNever]
        public ICollection<Crew> Member2 { get; set; } = null!; // navigation property

        [ValidateNever]
        public string EmployeeFullName => EmployeeFirstName + " " + EmployeeLastName;
    }
}
