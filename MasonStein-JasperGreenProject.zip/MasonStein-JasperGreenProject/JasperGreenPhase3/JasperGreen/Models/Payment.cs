﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - Payment Class
//PURPOSE:    The Payment class represents all information and context needed for Jasper Green
//            to create and manage payments.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace JasperGreen.Models
{
    public class Payment
    {

        public int PaymentID { get; set; }  // primary key property

        [Required(ErrorMessage = "Choose a customer.")]
        public int CustomerID { get; set; } // foreign key property

        public DateTime PaymentDate { get; set; }

        [Required(ErrorMessage = "Enter a payment amount.")]
        [Range(1, 2000, ErrorMessage = "Service fee should be greater than 0 and less than 2000.")]
        public double PaymentAmount { get; set; }

        [ValidateNever]
        public Customer Customer { get; set; } = null!; // navigation property

        [ValidateNever]
        public ICollection<ProvideService> ProvideServices { get; set; } = null!;   // navigation property
    }
}
