﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App
//PURPOSE:    The Customer controller manages the HTTP requests received by the web server
//            that are related to the Customer model.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using JasperGreen.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JasperGreen.Controllers
{
    public class CustomerController : Controller
    {

        //  The next two lines use dependency injection to make the JasperGreenContext
        //  available for the Customer Controller. This makes the JasperGreen database
        //  available for all the code in the controller.
        private JasperGreenContext Context {  get; set; }
        public CustomerController(JasperGreenContext ctx) => Context = ctx;

        //  redirect request for the Index action method to the List action method
        public IActionResult Index() => RedirectToAction("List");

        /// <summary>
        ///     The List() action method retreives a list of Customers from the database
        ///     and calls the List view. 
        /// </summary>
        /// <returns>List.cshtml view & customers list</returns>
        public IActionResult List()
        {
            var customers = Context.Customers
                .OrderBy(c => c.CustomerLastName)
                .ToList();

            return View(customers);
        }

        /// <summary>
        ///     The Add() action method returns the AddEdit view to the browser
        ///     with a new object.
        ///     The process sets the ViewBag Action to "Add" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form. 
        /// </summary>
        /// <returns>AddEdit.cshtml view & a new Customer object</returns>
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Customer());
        }

        /// <summary>
        ///     The Edit() action method returns the AddEdit view to the browser with 
        ///     an existing object. 
        ///     The process sets the ViewBag Action to "Edit" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form.
        /// </summary>
        /// <param name="id">The ID for the Customer to edit</param>
        /// <returns>AddEdit.cshtml view & existing Customer object</returns>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var customer = Context.Customers
                .Find(id);
            return View("AddEdit", customer);
        }

        /// <summary>
        ///     The Save() action method saves the new/edited record to the
        ///     JasperGreen database. 
        /// </summary>
        /// <param name="customer">An object containing a customer to add or update in the database</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Save(Customer customer)
        {
            //  check if the all the data validation checks passed
            //  if the data validation passsed, either add a new
            //  record or update the existing record
            //  redirect the action to the List action
            if (ModelState.IsValid)
            {
                if (customer.CustomerID == 0)
                {
                    Context.Customers
                        .Add(customer);
                }
                else
                {
                    Context.Customers
                        .Update(customer);
                }
                Context.SaveChanges();
                return RedirectToAction("List");
            }
            //  if the data validation does not pass, set the 
            //  ViewBag.Action property to indicate whether you
            //  are adding or editing a record and return the user
            //  to the AddEdit view
            else
            {
                if (customer.CustomerID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                return View("AddEdit",customer);
            }
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpGet version of the Delete action and has one input parameter.
        ///     The method uses the input to find the corresponding record
        ///     in the Customer table of the database. Then the object is 
        ///     passed to the Delete view. 
        /// </summary>
        /// <param name="id">The ID of a Customer to delete from the database.</param>
        /// <returns>Delete.cshtml view & a Customer object</returns>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var customer = Context.Customers
                .Find(id);
            return View(customer);
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpPost version of the Delete action and has one input parameter.
        ///     The method removes the record from the database. Then it 
        ///     redirects the action to the List action method. It also checks to make sure that
        ///     a record can be deleted (if it isn't in a one to many relationship).
        /// </summary>
        /// <param name="customer">The object of a Customer to delete from the database.</param>
        /// <returns>redirect to the List action method</returns>
        [HttpPost]
        public IActionResult Delete(Customer customer)
        {
            var c = Context.Customers.Find(customer.CustomerID);
            try
            {
                Context.Customers.Remove(c);
                Context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                // Provide user-friendly feedback
                TempData["message"] = $"{c.CustomerFullName} cannot be deleted because there are related records in the system.";
            }
            return RedirectToAction("List");
        }
    }
}
