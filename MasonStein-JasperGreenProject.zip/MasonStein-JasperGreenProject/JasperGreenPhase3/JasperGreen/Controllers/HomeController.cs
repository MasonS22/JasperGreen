﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App - HomeController
//PURPOSE:    The Home controller manages the HTTP requests received by the web server.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using Microsoft.AspNetCore.Mvc;

namespace JasperGreen.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        ///     The About() action method returns the about view to the browser. 
        ///     The about view is a relatively static page. Thus, the action 
        ///     method does not need any additional processing and returns 
        ///     the about view. 
        /// </summary>
        /// <returns>About.cshtml view</returns>
        public IActionResult About()
        {
            return View();
        }

        /// <summary>
        ///     The Index() action method returns the about view to the browser. 
        ///     The about view is a relatively static page. Thus, the action 
        ///     method does not need any additional processing and returns 
        ///     the index view. 
        /// </summary>
        /// <returns>Index.cshtml view</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        ///     The ContactUs() action method returns the contact view to the browser. 
        ///     The contactus view is a relatively static page. Thus, the action 
        ///     method does not need any additional processing and returns 
        ///     the contactus view. 
        /// </summary>
        /// <returns>ContactUs.cshtml view</returns>
        public IActionResult ContactUs()
        {
            return View();
        }
    }
}
