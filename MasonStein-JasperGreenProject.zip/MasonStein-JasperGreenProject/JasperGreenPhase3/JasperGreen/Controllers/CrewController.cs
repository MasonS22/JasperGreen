﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App
//PURPOSE:    The Crew controller manages the HTTP requests received by the web server
//            that are related to the Crew model.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using JasperGreen.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JasperGreen.Controllers
{
    public class CrewController : Controller
    {
        //  The next two lines use dependency injection to make the JasperGreenContext
        //  available for the Crew Controller. This makes the JasperGreen database
        //  available for all the code in the controller.
        private JasperGreenContext Context { get; set; }
        public CrewController(JasperGreenContext ctx) => Context = ctx;

        //  redirect request for the Index action method to the List action method
        public IActionResult Index() => RedirectToAction("List");

        /// <summary>
        ///     The List() action method retreives a list of Properties from the database
        ///     and calls the List view. Also puts lists of employees into the viewbag for use in 
        ///     the List view.
        /// </summary>
        /// <returns>List.cshtml view & employees list</returns>
        public IActionResult List()
        {
            var crews = Context.Crews
                .OrderBy(c => c.CrewID)
                .Include(c => c.CrewForeman)
				.Include(c => c.CrewMember1)
				.Include(c => c.CrewMember2)
				.ToList();

            return View(crews);
        }

        /// <summary>
        ///     The Add() action method returns the AddEdit view to the browser
        ///     with a new object.
        ///     The process sets the ViewBag Action to "Add" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form. Also creates a list of employees that will be used for a drop
        ///     down menu.
        /// </summary>
        /// <returns>AddEdit.cshtml view & a new Crew object</returns>
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Employees = Context.Employees
                .OrderBy(e => e.EmployeeLastName)
                .ToList();
            return View("AddEdit", new Crew());
        }

        /// <summary>
        ///     The Edit() action method returns the AddEdit view to the browser with 
        ///     an existing object. 
        ///     The process sets the ViewBag Action to "Edit" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form. Also creates a list of employees that will be used for a drop
        ///     down menu.
        /// </summary>
        /// <param name="id">The ID for the Crew to edit</param>
        /// <returns>AddEdit.cshtml view & existing Crew object</returns>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Employees = Context.Employees
                .OrderBy(e => e.EmployeeLastName)
                .ToList();
            var crew = Context.Crews
                .Find(id);
            return View("AddEdit", crew);
        }

        /// <summary>
        ///     The Save() action method saves the new/edited record to the
        ///     JasperGreen database. 
        /// </summary>
        /// <param name="crew">An object containing a crew to add or update in the database</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Save(Crew crew)
        {
            //  check if the all the data validation checks passed
            //  if the data validation passsed, either add a new
            //  record or update the existing record
            //  redirect the action to the List action
            if (ModelState.IsValid)
            {
                if (crew.CrewID == 0)
                {
                    Context.Crews
                        .Add(crew);
                }
                else
                {
                    Context.Crews
                        .Update(crew);
                }
                Context.SaveChanges();
                return RedirectToAction("List");
            }
            //  if the data validation does not pass, set the 
            //  ViewBag.Action property to indicate whether you
            //  are adding or editing a record and return the user
            //  to the AddEdit view
            else
            {
                if (crew.CrewID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                //Pass all employees to this view
                //so they can be used to create a
                //dropdown list.
                ViewBag.Employees = Context.Employees
                .OrderBy(e => e.EmployeeLastName)
                .ToList();
                return View("AddEdit", crew);
            }
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpGet version of the Delete action and has one input parameter.
        ///     The method uses the input to find the corresponding record
        ///     in the Crew table of the database. Then the object is 
        ///     passed to the Delete view. 
        /// </summary>
        /// <param name="id">The ID of a Crew to delete from the database.</param>
        /// <returns>Delete.cshtml view & a Crew object</returns>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var crew = Context.Crews
                .Find(id);
            return View(crew);
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpPost version of the Delete action and has one input parameter.
        ///     The method removes the record from the database. Then it 
        ///     redirects the action to the List action method. It also checks to make sure that
        ///     a record can be deleted (if it isn't in a one to many relationship).
        /// </summary>
        /// <param name="crew">The object of a Crew to delete from the database.</param>
        /// <returns>redirect to the List action method</returns>
        [HttpPost]
        public IActionResult Delete(Crew crew)
        {
            var c = Context.Crews.Find(crew.CrewID);
            try
            {
                Context.Crews.Remove(c);
                Context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                // Provide user-friendly feedback
                TempData["message"] = $"{c.CrewName} cannot be deleted because there are related records in the system.";
            }
            return RedirectToAction("List");
        }
    }
}
