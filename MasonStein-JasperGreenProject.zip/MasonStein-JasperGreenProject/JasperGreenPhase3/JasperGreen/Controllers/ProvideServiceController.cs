﻿//AUTHOR:     Mason Stein
//COURSE:     ISTM 415
//PROGRAM:    Jasper Green Web App
//PURPOSE:    The ProvideService controller manages the HTTP requests received by the web server
//            that are related to the ProvideService model.
//HONOR CODE: On my honor, as an Aggie, I have neither given
//			  nor received unauthorized aid on this academic work.

using JasperGreen.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JasperGreen.Controllers
{
    public class ProvideServiceController : Controller
    {
        //  The next two lines use dependency injection to make the JasperGreenContext
        //  available for the ProvideService Controller. This makes the JasperGreen database
        //  available for all the code in the controller.
        private JasperGreenContext Context { get; set; }
        public ProvideServiceController(JasperGreenContext ctx) => Context = ctx;

        //  redirect request for the Index action method to the List action method
        public IActionResult Index() => RedirectToAction("List");

        /// <summary>
        ///     The List() action method retreives a list of ProvideServices from the database
        ///     and calls the List view. Also puts a list of customers, properties,
        ///     payments, and crews into the viewbag for use in the List view.
        /// </summary>
        /// <returns>List.cshtml view & provideservices list</returns>
        public IActionResult List()
        {
            var services = Context.ProvideServices
                .OrderBy(p => p.ProvideServiceID)
                .Include(p => p.Customer)
                .Include(p => p.Property)
                .Include(p => p.Payment)
                .Include(p => p.Crew)
                .ToList();

            return View(services);
        }

        /// <summary>
        ///     The Add() action method returns the AddEdit view to the browser
        ///     with a new object.
        ///     The process sets the ViewBag Action to "Add" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form. Also creates a list of other models that will be used for other things.
        /// </summary>
        /// <returns>AddEdit.cshtml view & a new ProvideService object</returns>
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Customers = Context.Customers
                .OrderBy(c => c.CustomerLastName)
                .ToList();
            ViewBag.Properties = Context.Properties
                .OrderBy(p => p.PropertyID)
                .ToList();
            ViewBag.Payments = Context.Payments
                .OrderBy(p => p.PaymentID)
                .ToList();
            ViewBag.Crews = Context.Crews
                .OrderBy(c => c.CrewID)
                .ToList();
            var service = new ProvideService()
            {
                ProvideServiceDate = DateTime.Now
            };
            return View("AddEdit", service);
        }

        /// <summary>
        ///     The Edit() action method returns the AddEdit view to the browser with 
        ///     an existing object. 
        ///     The process sets the ViewBag Action to "Edit" to allow the AddEdit
        ///     view to determine whether to load a new form or edit an 
        ///     existing form. Also creates a list of other models that will be used for other things.
        /// </summary>
        /// <param name="id">The ID for the ProvideService to edit</param>
        /// <returns>AddEdit.cshtml view & existing ProvideService object</returns>
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Customers = Context.Customers
                .OrderBy(c => c.CustomerLastName)
                .ToList();
            ViewBag.Properties = Context.Properties
                .OrderBy(p => p.PropertyID)
                .ToList();
            ViewBag.Payments = Context.Payments
                .OrderBy(p => p.PaymentID)
                .ToList();
            ViewBag.Crews = Context.Crews
                .OrderBy(c => c.CrewID)
                .ToList();
            var service = Context.ProvideServices
                .Find(id);
            return View("AddEdit", service);
        }

        /// <summary>
        ///     The Save() action method saves the new/edited record to the
        ///     JasperGreen database. 
        /// </summary>
        /// <param name="service">An object containing a service to add or update in the database</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Save(ProvideService service)
        {
            //  check if the all the data validation checks passed
            //  if the data validation passsed, either add a new
            //  record or update the existing record
            //  redirect the action to the List action
            if (ModelState.IsValid)
            {
                if (service.ProvideServiceID == 0)
                {
                    Context.ProvideServices
                        .Add(service);
                }
                else
                {
                    Context.ProvideServices
                        .Update(service);
                }
                Context.SaveChanges();
                return RedirectToAction("List");
            }
            //  if the data validation does not pass, set the 
            //  ViewBag.Action property to indicate whether you
            //  are adding or editing a record and return the user
            //  to the AddEdit view
            else
            {
                if (service.ProvideServiceID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                //Pass all other models to this view
                //so they can be used to create
                //dropdown lists.
                ViewBag.Customers = Context.Customers
                .OrderBy(c => c.CustomerLastName)
                .ToList();
                ViewBag.Properties = Context.Properties
                .OrderBy(p => p.PropertyID)
                .ToList();
                ViewBag.Payments = Context.Payments
                    .OrderBy(p => p.PaymentID)
                    .ToList();
                ViewBag.Crews = Context.Crews
                    .OrderBy(c => c.CrewID)
                    .ToList();
                return View("AddEdit", service);
            }
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpGet version of the Delete action and has one input parameter.
        ///     The method uses the input to find the corresponding record
        ///     in the ProvideService table of the database. Then the object is 
        ///     passed to the Delete view. 
        /// </summary>
        /// <param name="id">The ID of a ProvideService to delete from the database.</param>
        /// <returns>Delete.cshtml view & a ProvideService object</returns>
        [HttpGet]
        public IActionResult Delete(int id)
        {
            ViewBag.Customers = Context.Customers
                .OrderBy(c => c.CustomerLastName)
                .ToList();
            ViewBag.Properties = Context.Properties
            .OrderBy(p => p.PropertyID)
            .ToList();
            ViewBag.Payments = Context.Payments
                .OrderBy(p => p.PaymentID)
                .ToList();
            ViewBag.Crews = Context.Crews
                .OrderBy(c => c.CrewID)
                .ToList();
            var service = Context.ProvideServices
                .Find(id);
            return View(service);
        }

        /// <summary>
        ///     The Delete() action method has two versions. This version handles
        ///     the HttpPost version of the Delete action and has one input parameter.
        ///     The method removes the record from the database. Then it 
        ///     redirects the action to the List action method. It also checks to make sure that
        ///     a record can be deleted (if it isn't in a one to many relationship).
        /// </summary>
        /// <param name="service">The object of a ProvideService to delete from the database.</param>
        /// <returns>redirect to the List action method</returns>
        [HttpPost]
        public IActionResult Delete(ProvideService service)
        {
            var p = Context.ProvideServices.Find(service.ProvideServiceID);
            try
            {
                Context.ProvideServices.Remove(p);
                Context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                // Provide user-friendly feedback
                TempData["message"] = $"{p.ProvideServiceID} cannot be deleted because there are related records in the system.";
            }
            return RedirectToAction("List");
        }
    }
}
